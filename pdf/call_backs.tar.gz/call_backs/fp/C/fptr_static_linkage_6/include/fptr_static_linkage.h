#ifndef __FPTR_STATIC_LINKAGE_H
#define __FPTR_STATIC_LINKAGE_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>

typedef enum {
	EVENT_TIMER_TRIGGERED = 1,
	EVENT_SIGNAL_RECEIVED,
	EVENT_CUSTOM_1,
	EVENT_CUSTOM_2,
	EVENT_CUSTOM_3,
	EVENT_CUSTOM_4,
	EVENT_INVALID,
}evt_t;

typedef void (*evt_cb_t)(void);

evt_cb_t get_evt();
evt_t register_event(evt_t evt, evt_cb_t cb);
void * evt_trigger_thread_fun(void *evt_trigger_data);

#define EVT_MAX	(256)
#define MODULE_NAME_MAX_LEN (256)
#endif
