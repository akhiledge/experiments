/** Program to illustrate the basic usage of callbacks;
 *  Statically linked function in this file is called
 *  from a different file which triggers an event
 */

#include "fptr_static_linkage.h"

static void evt_timer_triggered_listen_action()
{
	printf("%s\n", __func__);
}

static void evt_signal_received_listen_action()
{
	printf("%s\n", __func__);
}

static void evt_custom_1_listen_action()
{
	printf("%s\n", __func__);
}

static void evt_custom_2_listen_action()
{
	printf("%s\n", __func__);
}

static void evt_custom_3_listen_action()
{
	printf("%s\n", __func__);
}

static void evt_custom_4_listen_action()
{
	printf("%s\n", __func__);
}


evt_cb_t handle_post_event_action_cb[EVENT_INVALID] = {
	evt_timer_triggered_listen_action, /* EVENT_TIMER_TRIGGERED */
	evt_signal_received_listen_action, /* EVENT_SIGNAL_RECEIVED */
	evt_custom_1_listen_action, /* EVENT_CUSTOM_1 */
	evt_custom_2_listen_action, /* EVENT_CUSTOM_2 */
	evt_custom_3_listen_action, /* EVENT_CUSTOM_3 */
	evt_custom_4_listen_action, /* EVENT_CUSTOM_4 */
};

pthread_t evt_trigger_thread;
pthread_t evt_listen_thread;

unsigned short int evt_flags;

static void evt_timer_triggered_cb()
{
	evt_flags = EVENT_TIMER_TRIGGERED;
	
	return;
}

static void evt_signal_received_cb()
{
	evt_flags = EVENT_SIGNAL_RECEIVED;

	return;
}

static void evt_custom_1_cb()
{
	evt_flags = EVENT_CUSTOM_1;

	return;
}

static void evt_custom_2_cb()
{
	evt_flags = EVENT_CUSTOM_2;

	return;
}

static void evt_custom_3_cb()
{
	evt_flags = EVENT_CUSTOM_3;

	return;
}

static void evt_custom_4_cb()
{
	evt_flags = EVENT_CUSTOM_4;

	return;
}

void handle_post_event_action(unsigned short int evt_flags)
{
	if (handle_post_event_action_cb[evt_flags]) {
		(*handle_post_event_action_cb[evt_flags])();
	}

	sleep(1);
}

void * evt_listen_thread_fun(void *evt_listen_data)
{

	do {
		if ( EVENT_INVALID == register_event(EVENT_TIMER_TRIGGERED, evt_timer_triggered_cb)) {
			break;
		}

		if ( EVENT_INVALID == register_event(EVENT_SIGNAL_RECEIVED, evt_signal_received_cb)) {
			break;
		}

		if ( EVENT_INVALID == register_event(EVENT_CUSTOM_1, evt_custom_1_cb)) {
			break;
		}

		if ( EVENT_INVALID == register_event(EVENT_CUSTOM_2, evt_custom_2_cb)) {
			break;
		}

		if ( EVENT_INVALID == register_event(EVENT_CUSTOM_3, evt_custom_3_cb)) {
			break;
		}

		if ( EVENT_INVALID == register_event(EVENT_CUSTOM_4, evt_custom_4_cb)) {
			break;
		}

	} while(0);

	while(1) {
		handle_post_event_action(evt_flags);
	}

	return (void *) NULL;
}

int main()
{
	if (pthread_create(&evt_trigger_thread, NULL, evt_trigger_thread_fun, NULL)) {
		fprintf(stderr, "Error creating evt_trigger_thread \n");
		return 1;
	}

	if (pthread_create(&evt_listen_thread, NULL, evt_listen_thread_fun, NULL)) {
		fprintf(stderr, "Error creating evt_listen_thread_fun \n");
		return 1;
	}


	if (pthread_join(evt_listen_thread, NULL)) {
		fprintf(stderr, "Error joining evt_listen_thread\n");
		return 1;
	}

	if (pthread_join(evt_trigger_thread, NULL)) {
		fprintf(stderr, "Error joining evt_trigger_thread\n");
		return 1;
	}

	return 0;
}
