/** Program file which calls a registered callback on event occurance */

#include "fptr_static_linkage.h"

typedef struct evt_registrations {
	evt_t event;
	evt_cb_t cb;
}evt_regs;

evt_regs registered_events[EVT_MAX];


void * evt_trigger_thread_fun(void *evt_trigger_data)
{
        evt_cb_t cb;

        printf("Inside %s\n", __func__);

        do {
                cb = get_evt();
                if (cb)
                        (*cb)();
                sleep(1);
        } while (1);

        return (void *) NULL;
}


#define randnum(min, max) \
	((rand() % (int)(((max) + 1) - (min))) + (min))

evt_cb_t get_evt()
{
	int rand_gen = -1;

	srand(time(NULL));
	rand_gen = randnum(EVENT_TIMER_TRIGGERED, EVENT_CUSTOM_4);

	return registered_events[rand_gen].cb;
}

evt_t register_event(evt_t evt, evt_cb_t cb)
{
	if (EVENT_INVALID == evt) {
	        printf("%s:%d: Event registration failed for %d\n", __func__, __LINE__, evt);
		return EVENT_INVALID;
	}

	printf("%d:registered_events[evt].event = %d\n", __LINE__, registered_events[evt].event);

	if (registered_events[evt].event == evt) {
	        printf("%s:%d: Event registration failed for %d\n", __func__, __LINE__, evt);
		return EVENT_INVALID;
	}

	registered_events[evt].event = evt;
	registered_events[evt].cb = cb;

	printf("%d:registered_events[evt].event = %d\n", __LINE__, registered_events[evt].event);

	return evt;
}
