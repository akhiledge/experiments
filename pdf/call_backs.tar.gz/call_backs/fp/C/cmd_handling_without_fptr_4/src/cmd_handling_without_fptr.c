/** Program to illustrate code saving using function pointers */

#include <stdio.h>
#include "cmd_handling_without_fptr.h"

typedef enum command_list {
	CMD_PERFORM_ADDITION,
	CMD_PERFORM_SUBTRACTION,
	CMD_PERFORM_DIVISION,
	CMD_PERFORM_MULTIPLICATION,
	CMD_INVALID,
}cmd_t;

#define CMD_MAX_LEN (256)
const char * cmd_str_list [][CMD_MAX_LEN] = {
						{ "CMD_PERFORM_ADDITION" },
						{ "CMD_PERFORM_SUBTRACTION" } ,
						{ "CMD_PERFORM_DIVISION" },
						{ "CMD_PERFORM_MULTIPLICATION" },
						{ "CMD_INVALID" },
					};

cmd_t get_cmd_enum(const char * cmd_name)
{
	if (!cmd_name) {
		return CMD_INVALID;
	}

	if (!strncmp(cmd_name, "CMD_PERFORM_ADDITION", sizeof("CMD_PERFORM_ADDITION") - 1)) {
		return CMD_PERFORM_ADDITION;
	} else if (!strncmp(cmd_name, "CMD_PERFORM_SUBTRACTION", sizeof("CMD_PERFORM_SUBTRACTION") - 1)) {
		return CMD_PERFORM_SUBTRACTION;
	} else if (!strncmp(cmd_name, "CMD_PERFORM_DIVISION", sizeof("CMD_PERFORM_DIVISION") - 1)) {
		return CMD_PERFORM_DIVISION;
	} else if (!strncmp(cmd_name, "CMD_PERFORM_MULTIPLICATION", sizeof("CMD_PERFORM_MULTIPLICATION") - 1)) {
		return CMD_PERFORM_MULTIPLICATION;
	} else {
		return CMD_INVALID;
	}
}

void do_addition(cmd_t cmd, long int op1_val, long int op2_val)
{
	printf("%s: addition(%ld, %ld) = %ld\n", __func__, op1_val, op2_val, (op1_val + op2_val));
}

void do_subtraction(cmd_t cmd, long int op1_val, long int op2_val)
{
	printf("%s: subtraction(%ld, %ld) = %ld\n", __func__, op1_val, op2_val, (op1_val - op2_val));
}

void do_division(cmd_t cmd, long int op1_val, long int op2_val)
{
	if (!op2_val) {
		printf("%s: op2_val can not be zero\n", __func__);
		return;
	}

	printf("%s: division(%ld, %ld) = %ld\n", __func__, op1_val, op2_val, (op1_val / op2_val));
}

void do_multiplication(cmd_t cmd, long int op1_val, long int op2_val)
{
	printf("%s: multiplication(%ld, %ld) = %ld\n", __func__, op1_val, op2_val, (op1_val * op2_val));
}

void handle_operation(cmd_t cmd, long int op1_val, long int op2_val)
{
	if (CMD_PERFORM_ADDITION == cmd) {
		do_addition(cmd, op1_val, op2_val);
	} else if (CMD_PERFORM_SUBTRACTION == cmd) {
		do_subtraction(cmd, op1_val, op2_val);
	} else if (CMD_PERFORM_DIVISION == cmd) {
		do_division(cmd, op1_val, op2_val);
	} else if (CMD_PERFORM_MULTIPLICATION == cmd) {
		do_multiplication(cmd, op1_val, op2_val);
	}
}

int main(int argc, char *argv[])
{
	const char *cmd_arg = NULL;
	const char *op1 = NULL;
	const char *op2 = NULL;

	long int op1_val;
	long int op2_val;

	cmd_t cmd;

	if (argc != 4) {
		printf("%s: <CMD_PERFORM_ADDITION/CMD_PERFORM_SUBTRACTION/CMD_PERFORM_DIVISION/CMD_PERFORM_MULTIPLICATION> <x> <y>\n", argv[0]);
		return 1;
	}

	cmd_arg = argv[1];

	if (CMD_INVALID == (cmd = get_cmd_enum(cmd_arg))) {
		printf ("%s: Invalid command\n", argv[0]);
		return 1;
	}

	op1 = argv[2];
	op1_val = strtol(op1, NULL, 10);

	if ((op1_val == LONG_MIN) || (op1_val == LONG_MAX)) {
		printf ("%s: First operand input is wrong\n", argv[0]);
		return 1;
	}
	
	op2 = argv[3];
	op2_val = strtol(op2, NULL, 10);

	if ((op2_val == LONG_MIN) || (op2_val == LONG_MAX)) {
		printf ("%s: second: operand input is wrong\n", argv[0]);
		return 1;
	}

	handle_operation(cmd, op1_val, op2_val);

	return 0;
}
