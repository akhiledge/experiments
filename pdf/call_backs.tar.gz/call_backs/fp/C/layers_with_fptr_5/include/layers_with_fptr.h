#ifndef __FUN_BASICS_H
#define __FUN_BASICS_H

#include <stdio.h>

typedef void (*sum_fun_ptr)(int, int);
void init_sum_module();
void register_sum_operation(sum_fun_ptr sum_fun);

#endif
