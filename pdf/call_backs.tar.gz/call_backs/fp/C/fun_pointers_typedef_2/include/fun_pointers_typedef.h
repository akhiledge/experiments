#ifndef __FUN_BASICS_H
#define __FUN_BASICS_H


#endif
